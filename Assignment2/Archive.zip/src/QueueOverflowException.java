
@SuppressWarnings("serial")
public class QueueOverflowException extends Exception {
	public QueueOverflowException() {
super("Queue has overflowed.");
}
}