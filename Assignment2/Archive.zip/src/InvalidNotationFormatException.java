
@SuppressWarnings("serial")
public class InvalidNotationFormatException extends Exception{
	public InvalidNotationFormatException() {
super("Improper notation format.");
	}
}
