
@SuppressWarnings("serial")
public class StackOverflowException extends Exception {
	public StackOverflowException() {
		super("Stack has been overflowed.");
	}

}
