
@SuppressWarnings("serial")
public class StackUnderflowException extends Exception {
	
	public StackUnderflowException() {
		super("The stack under flowed.");
	}

}
