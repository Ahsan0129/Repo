
@SuppressWarnings("serial")
public class QueueUnderflowException extends Exception {
public QueueUnderflowException() {
	super("Queue has underflowed.");
}
}
